# Kodiaddon
KodiAddons to start python apps for 5schatten/LibreELEC.tv

Thanks to https://github.com/5schatten/LibreELEC.tv

Forum https://forum.libreelec.tv/thread/12662


Kodi addons to start different apps on the build from 5schatten

Chrome

Spotify

Emulationstation

Pegasus frontend

Retroarch

For use on another skin like aeon mq8

Just install the addon and add the program addon somewhere in the menu

If you have any request let me know
